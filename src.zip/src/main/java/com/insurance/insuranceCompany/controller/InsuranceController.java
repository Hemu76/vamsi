package com.insurance.insuranceCompany.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.insurance.insuranceCompany.model.LoginClass;
import com.insurance.insuranceCompany.model.OTPclass;
import com.insurance.insuranceCompany.repository.NetworkHospitalRepository;
import com.insurance.insuranceCompany.repository.PackagesRepository;
import com.insurance.insuranceCompany.repository.RepositoryAdmin;

@Controller
public class InsuranceController {
	RepositoryAdmin rep;
	NetworkHospitalRepository nhr;
	PackagesRepository pr;
	HttpSession session;

	@Autowired
	public InsuranceController(RepositoryAdmin rep, NetworkHospitalRepository nhr, PackagesRepository pr,
			HttpSession session) {
		this.rep = rep;
		this.nhr = nhr;
		this.pr = pr;
		this.session = session;
	}

	@GetMapping({ "/login", "insurancelogin", "/" })
	public String loginPage(Model model) {
		session.setAttribute("login", 0);
		model.addAttribute("error", true);
		model.addAttribute("login", new LoginClass());
		return "loginPage"; // Return the name of your login Thymeleaf template
	}

	@PostMapping("/login")
	public String loginSubmit() {
		// Spring Security handles authentication
		return "redirect:/dashboard"; // Redirect to the dashboard upon successful login
	}

	@GetMapping("/dashboard")
	public String dashboard(Model model) {
		Object lc = session.getAttribute("login");
		System.out.println(lc);
		if (lc == null || (int) lc == 0) {
			model.addAttribute("noaccess", "you need to login first");
			model.addAttribute("login", new LoginClass());
			return "loginPage";
		}
		model.addAttribute("hospitalCount", nhr.getHospitalsCount());
		model.addAttribute("packageCount", pr.getPackagesCount());
		return "dashboard";
	}
	

	@GetMapping("/forgotpassword")
	public String forgotpassword(Model model) {
		model.addAttribute("to", "");
		model.addAttribute("login", new OTPclass());
		model.addAttribute("enotp", "");
		model.addAttribute("otp", "");

		return "forgotPasswordPage";
	}

	@GetMapping("/signout")
	public String signout(Model model) {
		session.setAttribute("login", 0);
		model.addAttribute("login", new LoginClass());
		return "loginPage";
	}
}
