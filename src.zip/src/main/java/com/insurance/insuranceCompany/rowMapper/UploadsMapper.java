package com.insurance.insuranceCompany.rowMapper;


import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.insurance.insuranceCompany.model.Uploads;

public class UploadsMapper implements RowMapper<Uploads> {

    @Override
    public Uploads mapRow(ResultSet rs, int rowNum) throws SQLException {
        Uploads uploads = new Uploads();
        uploads.setUploadId(rs.getInt("uploadId"));
        uploads.setReUploadId(rs.getInt("reUploadId"));
        uploads.setClaimId(rs.getInt("claimId"));
        uploads.setData(rs.getString("data"));
        uploads.setType(rs.getString("type"));
        return uploads;
    }
}

